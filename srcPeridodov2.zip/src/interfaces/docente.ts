export interface Docente{
    id:number;
    identificacion: number;
    nombre:string;
    apellido: string;
    genero: string;
    estudio: string;
    correo: string;
    estado: number;
    rol: string
}