export interface Usuario{
    user:string,
    password:string
}